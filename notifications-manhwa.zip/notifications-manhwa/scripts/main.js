/* Notifications Manhwa — diffusion en direct de notifications « Système / Constellations » (style ORV)
   Foundry VTT v12 / v13 */
const MID = "notifications-manhwa";
const SOCK = `module.${MID}`;
const SOUNDS = ["neutre", "systeme", "doux", "cloche", "upbeat", "victoire", "mystique", "alerte", "danger", "echec", "ominous", "sombre", "abysse", "tambour", "glitch"];
const THEMES = ["rouge", "cramoisi", "sang", "orange-alerte", "orange", "jaune", "or", "vert", "toxique", "emeraude", "cyan", "bleu", "bleu-roi", "turquoise", "acier", "violet", "violet-doux", "plasma", "nebula", "rose", "blanc", "noir"];
const FONTS = ["system", "cosmic", "classic", "mono", "impact"];
const ApplicationV2 = foundry.applications.api.ApplicationV2;
const esc = s => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const uid = () => (foundry.utils.randomID ? foundry.utils.randomID(12) : Math.random().toString(36).slice(2, 14));

/* ───────────────── Couleurs personnalisées (identique à l'outil) ───────────────── */
function nmHex2rgb(h){ h=String(h||"#1e7ae8").replace("#",""); if(h.length===3) h=h.split("").map(c=>c+c).join(""); const n=parseInt(h.slice(0,6),16); return [(n>>16)&255,(n>>8)&255,n&255]; }
function nmRgb2hsl(r,g,b){ r/=255;g/=255;b/=255; const mx=Math.max(r,g,b),mn=Math.min(r,g,b); let h=0,s=0; const l=(mx+mn)/2; if(mx!==mn){ const d=mx-mn; s=l>.5?d/(2-mx-mn):d/(mx+mn); if(mx===r) h=(g-b)/d+(g<b?6:0); else if(mx===g) h=(b-r)/d+2; else h=(r-g)/d+4; h/=6; } return [h,s,l]; }
function nmHsl2rgb(h,s,l){ if(s===0){ const v=Math.round(l*255); return [v,v,v]; } const q=l<.5?l*(1+s):l+s-l*s, p=2*l-q; const f=t=>{ if(t<0)t+=1; if(t>1)t-=1; if(t<1/6) return p+(q-p)*6*t; if(t<1/2) return q; if(t<2/3) return p+(q-p)*(2/3-t)*6; return p; }; return [Math.round(f(h+1/3)*255),Math.round(f(h)*255),Math.round(f(h-1/3)*255)]; }
function nmShade(hex,dl,ds){ const [h,s,l]=nmRgb2hsl(...nmHex2rgb(hex)); const [r,g,b]=nmHsl2rgb(h,Math.max(0,Math.min(1,s+(ds||0))),Math.max(0,Math.min(1,l+dl))); return "#"+[r,g,b].map(v=>v.toString(16).padStart(2,"0")).join(""); }
function nmRgba(hex,a){ const [r,g,b]=nmHex2rgb(hex); return `rgba(${r},${g},${b},${a})`; }
function nmCustomVars(main, glow){
  main = main || "#1e7ae8"; glow = glow || nmShade(main, .28, .1);
  return { "--t-bar1": nmShade(main,-.14), "--t-bar2": nmShade(main,-.10), "--t-bar3": nmShade(main,-.07), "--t-main1": nmShade(main,-.03), "--t-main2": main, "--t-main3": nmShade(main,.05),
    "--t-glow": nmRgba(glow,.9), "--t-border": nmRgba(glow,.4), "--t-corner": nmRgba(nmShade(glow,.15),.8), "--t-side": nmShade(glow,.06), "--t-hline": nmRgba(glow,.6), "--t-hcenter": nmRgba(nmShade(glow,.3),.97),
    "--t-card-border": nmRgba(glow,.67), "--t-card-border2": nmRgba(nmShade(main,-.12),.27), "--t-card-inset": nmRgba(nmShade(glow,.1),.53), "--t-botbar-txt": nmRgba(nmShade(glow,.15),.45), "--t-scan": nmRgba(nmShade(glow,.25),.4), "--t-deco": nmRgba(nmShade(glow,.15),.55) };
}
const VAR_KEYS = Object.keys(nmCustomVars("#000"));

/* ───────────────── Réglages ───────────────── */
Hooks.once("init", () => {
  const S = (k, o) => game.settings.register(MID, k, o);
  S("registry", { scope: "world", config: false, type: Object, default: {} });
  S("library", { scope: "world", config: false, type: Object, default: { cats: [], presets: [] } });
  S("defaults", { scope: "world", config: false, type: Object, default: {} });
  S("history", { scope: "world", config: false, type: Array, default: [] });
  S("journal", { scope: "client", config: false, type: Array, default: [] });
  S("playersJournal", { name: "Journal pour les joueurs", hint: "Les joueurs peuvent rouvrir le journal des notifications reçues (bouton dans les contrôles de scène).", scope: "world", config: true, type: Boolean, default: true });
  S("journalSize", { name: "Taille du journal", hint: "Nombre de notifications conservées dans le journal de chaque client.", scope: "world", config: true, type: Number, default: 100, range: { min: 10, max: 500, step: 10 } });
  S("maxStack", { name: "Notifications simultanées", hint: "Au-delà, les suivantes attendent en file.", scope: "world", config: true, type: Number, default: 3, range: { min: 1, max: 6, step: 1 } });
  S("allowModuleApi", { name: "API ouverte aux joueurs", hint: "Autorise les diffusions déclenchées côté joueur par d'autres modules (ex. paliers de statistiques de Fiche Manhwa). Les joueurs n'ont jamais accès à l'outil de diffusion lui-même.", scope: "world", config: true, type: Boolean, default: true });
  S("chatAlias", { name: "Nom d'expéditeur dans le chat", scope: "world", config: true, type: String, default: "Système" });
  S("muteSounds", { name: "Couper les sons (ce client)", scope: "client", config: true, type: Boolean, default: false });
  S("volumeScale", { name: "Volume des notifications (ce client)", hint: "Multiplicateur appliqué au volume choisi par le MJ.", scope: "client", config: true, type: Number, default: 100, range: { min: 0, max: 100, step: 5 } });
  S("windowWidth", { scope: "client", config: false, type: Number, default: 1420 });
  S("windowHeight", { scope: "client", config: false, type: Number, default: 940 });
  game.keybindings?.register(MID, "openTool", { name: "Ouvrir l'outil de diffusion (MJ)", editable: [], onDown: () => { if (game.user.isGM) openTool(); return true; } });
  game.keybindings?.register(MID, "openJournal", { name: "Ouvrir le journal des notifications", editable: [], onDown: () => { openJournal(); return true; } });
});

/* ───────────────── Fenêtre MJ (iframe) ───────────────── */
class NotifTool extends ApplicationV2 {
  static DEFAULT_OPTIONS = { id: "nm-tool", classes: ["nm-frame"], window: { title: "Notifications Manhwa", icon: "fa-solid fa-satellite-dish", resizable: true, minimizable: true }, position: { width: 1420, height: 940 } };
  async _prepareContext() { return {}; }
  async _renderHTML() { const f = document.createElement("iframe"); f.className = "nm-iframe"; f.src = `modules/${MID}/app/notif.html`; this.frame = f; return f; }
  _replaceHTML(result, content) { content.replaceChildren(result); }
  _onClose(o) { super._onClose?.(o); if (this.position?.width) { game.settings.set(MID, "windowWidth", Math.round(this.position.width)); game.settings.set(MID, "windowHeight", Math.round(this.position.height)); } tool = null; }
}
let tool = null;
function openTool() {
  if (!game.user.isGM) return ui.notifications.warn("L'outil de diffusion est réservé au MJ.");
  if (!tool) tool = new NotifTool({ position: { width: game.settings.get(MID, "windowWidth"), height: game.settings.get(MID, "windowHeight") } });
  tool.render({ force: true }); return tool;
}
function usersList() { return game.users.map(u => ({ id: u.id, name: u.name, color: (u.color?.css ?? u.color ?? "#38e0ff").toString(), active: u.active, isGM: u.isGM })); }
function post(msg) { tool?.frame?.contentWindow?.postMessage(msg, "*"); }
function initFrame(win) {
  win.postMessage({ type: "nm-init", registry: game.settings.get(MID, "registry"), library: game.settings.get(MID, "library"), defaults: game.settings.get(MID, "defaults"), history: game.settings.get(MID, "history"), users: usersList(), sub: `Monde : ${game.world.title} · ${game.users.filter(u => u.active && !u.isGM).length} joueur(s) en ligne` }, "*");
}
function FP() { return foundry.applications?.apps?.FilePicker?.implementation ?? foundry.applications?.apps?.FilePicker ?? globalThis.FilePicker; }
window.addEventListener("message", async ev => {
  const m = ev.data || {}; if (!m || typeof m.type !== "string" || !m.type.startsWith("nm-")) return;
  const win = ev.source; if (win !== tool?.frame?.contentWindow) return;
  if (!game.user.isGM) return;
  if (m.type === "nm-ready") initFrame(win);
  else if (m.type === "nm-save") { if (["registry", "library", "defaults"].includes(m.key)) await game.settings.set(MID, m.key, m.value ?? {}); }
  else if (m.type === "nm-broadcast") await broadcast(m.payload);
  else if (m.type === "nm-replay") { const h = game.settings.get(MID, "history").find(x => x.id === m.id); if (h) await broadcast(foundry.utils.deepClone(h), true); }
  else if (m.type === "nm-history-clear") await game.settings.set(MID, "history", []);
  else if (m.type === "nm-preview") playSound(m, true);
  else if (m.type === "nm-tokens") { const ids = new Set(); for (const t of canvas?.tokens?.controlled ?? []) for (const u of game.users) if (!u.isGM && t.actor?.testUserPermission(u, "OWNER")) ids.add(u.id); win.postMessage({ type: "nm-tokens", ids: [...ids] }, "*"); }
  else if (m.type === "nm-pick") { const Cls = FP(); if (!Cls) return; new Cls({ type: m.what === "sound" ? "audio" : "image", callback: path => win.postMessage({ type: "nm-picked", what: m.what, path }, "*") }).browse(); }
});
Hooks.on("userConnected", () => post({ type: "nm-users", users: usersList() }));
Hooks.on("updateSetting", (s, c, o, userId) => { if (s.key === `${MID}.history`) post({ type: "nm-history", history: game.settings.get(MID, "history") }); if (s.key === `${MID}.registry` && userId !== game.user.id) post({ type: "nm-registry", registry: game.settings.get(MID, "registry") }); });

/* ───────────────── Charge utile ───────────────── */
function renderMarkup(txt) { let h = esc(txt); h = h.replace(/\{(or|sang|cyan|violet|vert|bleu|rose|argent)\}([\s\S]*?)\{\/(?:\1)?\}/g, '<span class="mk-$1">$2</span>'); return h.replace(/\n/g, "<br>"); }
function normalize(p) {
  const o = {};
  o.id = typeof p.id === "string" ? p.id.slice(0, 24) : uid();
  o.text = String(p.text ?? "").slice(0, 2000);
  o.font = FONTS.includes(p.font) ? p.font : "system";
  o.theme = THEMES.includes(p.theme) ? p.theme : (p.theme === "custom" ? "custom" : "bleu");
  if (p.colors?.main) o.vars = nmCustomVars(p.colors.main, p.colors.glow);
  else if (p.vars && typeof p.vars === "object") { o.vars = {}; for (const k of VAR_KEYS) if (typeof p.vars[k] === "string" && /^(#[0-9a-f]{3,8}|rgba?\([\d.,\s]+\))$/i.test(p.vars[k])) o.vars[k] = p.vars[k]; }
  else o.vars = null;
  if (o.theme === "custom" && !o.vars) o.theme = "bleu";
  o.cat = p.cat && typeof p.cat === "object" ? { ic: String(p.cat.ic ?? "").slice(0, 4), nom: String(p.cat.nom ?? "").slice(0, 40) } : null;
  o.top = String(p.top ?? "SYS::CONSTELLATION_LINK").slice(0, 60); o.bot = String(p.bot ?? "CONSTELLATION.NETWORK · NOTIFICATION.SYS").slice(0, 80);
  o.image = typeof p.image === "string" && /^(https?:\/\/|[\w\-./ ]+\.(png|jpe?g|webp|gif|svg))/i.test(p.image) ? p.image.slice(0, 500) : "";
  o.duration = Math.max(0, Math.min(3600, Number(p.duration ?? 8) || 0)); o.dismiss = p.dismiss !== false;
  o.position = ["top", "center", "bottom"].includes(p.position) ? p.position : "center";
  o.width = Math.max(320, Math.min(1600, Number(p.width) || 760)); o.zoom = Math.max(50, Math.min(200, Number(p.zoom) || 100));
  o.sound = SOUNDS.includes(p.sound) ? p.sound : (p.sound === "custom" ? "custom" : "");
  o.soundPath = o.sound === "custom" && typeof p.soundPath === "string" ? p.soundPath.slice(0, 500) : "";
  o.volume = Math.max(0, Math.min(100, Number(p.volume ?? 80) || 0)); o.chat = !!p.chat;
  o.targets = p.targets === "all" || !Array.isArray(p.targets) ? "all" : p.targets.filter(x => typeof x === "string").slice(0, 50);
  o.gmToo = p.gmToo !== false; o.seed = Number(p.seed) || 0; o.mode = String(p.mode ?? "une"); o.name = String(p.name ?? "").slice(0, 120);
  return o;
}
async function broadcast(raw, replay = false) {
  const p = normalize(raw); p.from = game.user.id; p.ts = Date.now(); if (replay) p.id = uid();
  if (!p.text) return;
  game.socket.emit(SOCK, { type: "show", payload: p });
  receive(p);
  if (p.chat) await chatCopy(p);
  if (game.user.isGM) { const h = game.settings.get(MID, "history"); h.unshift(p); await game.settings.set(MID, "history", h.slice(0, 60)); }
  Hooks.callAll("notificationsManhwa.broadcast", p);
}
async function chatCopy(p) {
  const style = p.vars ? Object.entries(p.vars).map(([k, v]) => `${k}:${v}`).join(";") : "";
  const content = `<div class="nm-chat theme-${p.theme === "custom" ? "bleu" : p.theme}" style="${style}"><div class="nm-chat-top"><span>${esc(p.top)}</span><span>${p.cat ? esc(p.cat.ic + " " + p.cat.nom) : ""}</span></div>${p.image ? `<img src="${esc(p.image)}" style="display:block;max-width:100%;margin:6px auto 0;border-radius:3px">` : ""}<div class="nm-chat-txt font-${p.font}">${renderMarkup(p.text)}</div><button type="button" class="nm-chat-replay" data-nm="${p.id}">RÉAFFICHER</button></div>`;
  const whisper = p.targets === "all" ? [] : [...new Set([...p.targets, ...game.users.filter(u => u.isGM).map(u => u.id)])];
  await ChatMessage.create({ content, whisper, speaker: { alias: game.settings.get(MID, "chatAlias") || "Système" }, flags: { [MID]: { payload: p } } });
}
/* clic « RÉAFFICHER » dans le chat */
document.addEventListener("click", ev => {
  const b = ev.target?.closest?.(".nm-chat-replay"); if (!b) return;
  const li = b.closest("[data-message-id]"); const msg = li && game.messages.get(li.dataset.messageId);
  const p = msg?.getFlag(MID, "payload"); if (p) showCard(Object.assign({}, normalize(p), { dismiss: true, targets: "all" }), true);
});

/* ───────────────── Réception ───────────────── */
function receive(p) {
  const me = game.user.id;
  if (p.from === me) { if (!p.gmToo) return; }
  else if (p.targets !== "all" && !p.targets.includes(me)) return;
  showCard(p); playSound(p); journalAdd(p);
  Hooks.callAll("notificationsManhwa.received", p);
}
function playSound(p, preview = false) {
  if (game.settings.get(MID, "muteSounds") && !preview) return;
  const src = p.sound === "custom" ? p.soundPath : (p.sound ? `modules/${MID}/sounds/${p.sound}.ogg` : "");
  if (!src) return;
  const volume = Math.max(0, Math.min(1, (Number(p.volume ?? 80) / 100) * (game.settings.get(MID, "volumeScale") / 100)));
  const AH = foundry.audio?.AudioHelper ?? globalThis.AudioHelper;
  try { AH.play({ src, volume, autoplay: true, loop: false }, false); } catch (e) { console.warn(`${MID} | son`, e); }
}
function journalAdd(p) {
  const j = game.settings.get(MID, "journal"); j.unshift(p);
  game.settings.set(MID, "journal", j.slice(0, game.settings.get(MID, "journalSize")));
  if (journal?.rendered) journal.render();
}

/* ───────────────── Calque d'affichage ───────────────── */
const active = []; const queue = [];
function layer() {
  let l = document.getElementById("nm-layer");
  if (!l) { l = document.createElement("div"); l.id = "nm-layer"; l.innerHTML = '<div class="nm-stack"></div>'; document.body.appendChild(l); }
  return l;
}
function starsSvg(seed) {
  let a = (seed >>> 0) || 7; const rnd = () => { a = (a * 1664525 + 1013904223) >>> 0; return a / 4294967296; };
  const pts = []; for (let i = 0; i < 22; i++) pts.push([rnd() * 1000, rnd() * 260]);
  let h = ""; pts.forEach((p, i) => { h += `<circle cx="${p[0].toFixed(1)}" cy="${p[1].toFixed(1)}" r="${(0.6 + rnd() * 1.4).toFixed(2)}"/>`; if (i && rnd() < .55) { const q = pts[i - 1]; h += `<path d="M${q[0].toFixed(1)} ${q[1].toFixed(1)} L${p[0].toFixed(1)} ${p[1].toFixed(1)}"/>`; } });
  return h;
}
function cardHTML(p) {
  const style = p.vars ? Object.entries(p.vars).map(([k, v]) => `${k}:${v}`).join(";") : "";
  const cls = p.vars ? "" : ` theme-${p.theme}`;
  return `<div class="notif-card${cls}" style="${style}">
    <div class="notif-topbar"><div class="notif-topbar-deco"><div class="deco-corner"></div><div class="deco-corner2"></div></div>
      <div class="notif-topbar-txt"><i></i><span>${esc(p.top)}</span></div>
      ${p.cat ? `<div class="notif-cat on"><b>${esc(p.cat.ic)}</b>${esc(p.cat.nom)}</div>` : ""}
      <div class="win-btn">—</div><div class="win-btn">□</div><div class="win-btn">✕</div></div>
    <div class="notif-main"><div class="n-hex"></div><div class="n-sheen"></div><div class="n-lines"></div>
      <svg class="n-stars" viewBox="0 0 1000 260" preserveAspectRatio="none">${starsSvg(p.seed)}</svg>
      <div class="n-ticks l"></div><div class="n-ticks r"></div><div class="scan"></div>
      <div class="notif-body"><div class="corner-tl"></div><div class="corner-tr"></div><div class="corner-bl"></div><div class="corner-br"></div>
        <div class="h-line"></div>${p.image ? `<img class="nm-img" src="${esc(p.image)}" alt="">` : ""}<div class="notif-text font-${p.font}">${renderMarkup(p.text)}</div><div class="h-line"></div></div></div>
    <div class="notif-botbar"><div class="notif-botbar-left"><i></i><i></i><i></i><i></i></div><div class="notif-botbar-txt">${esc(p.bot)}</div><div class="notif-botbar-deco"></div></div>
  </div>`;
}
function showCard(p, local = false) {
  if (active.length >= game.settings.get(MID, "maxStack")) { queue.push(p); return; }
  const l = layer(); l.className = `pos-${p.position}`; const stack = l.querySelector(".nm-stack");
  stack.style.setProperty("--nm-w", p.width + "px");
  const item = document.createElement("div"); item.className = "nm-item" + (p.dismiss || !p.duration ? " clickable" : ""); item.style.setProperty("--nm-zoom", p.zoom / 100);
  item.innerHTML = cardHTML(p) + (p.duration ? '<div class="nm-timer"></div>' : "") + (p.dismiss || !p.duration ? '<div class="nm-hint">CLIQUER POUR FERMER</div>' : "");
  stack.appendChild(item); active.push(item);
  let done = false;
  const close = () => { if (done) return; done = true; item.classList.add("out"); setTimeout(() => { item.remove(); const i = active.indexOf(item); if (i >= 0) active.splice(i, 1); if (queue.length) showCard(queue.shift()); }, 380); };
  if (p.dismiss || !p.duration) item.addEventListener("click", close);
  if (p.duration) { const bar = item.querySelector(".nm-timer"); requestAnimationFrame(() => { bar.style.transition = `transform ${p.duration}s linear`; bar.style.transform = "scaleX(0)"; }); setTimeout(close, p.duration * 1000); }
  return close;
}

/* ───────────────── Journal (joueurs & MJ) ───────────────── */
class NotifJournal extends ApplicationV2 {
  static DEFAULT_OPTIONS = { id: "nm-journal", classes: ["nm-journal"], window: { title: "Journal des notifications", icon: "fa-solid fa-book-open", resizable: true }, position: { width: 520, height: 600 } };
  async _prepareContext() { return {}; }
  async _renderHTML() {
    const j = game.settings.get(MID, "journal"); const wrap = document.createElement("div"); wrap.style.cssText = "display:flex;flex-direction:column;height:100%";
    const list = document.createElement("div"); list.className = "nm-journal-list";
    if (!j.length) list.innerHTML = '<div class="nm-journal-empty">AUCUNE NOTIFICATION REÇUE</div>';
    for (const p of j) {
      const row = document.createElement("div"); row.className = "nm-jrow"; row.style.setProperty("--jc", p.vars?.["--t-main2"] ?? themeColor(p.theme));
      const d = new Date(p.ts || 0); row.innerHTML = `<div class="nm-jt font-${esc(p.font)}">${renderMarkup(p.text)}</div><div class="nm-jd">${esc(d.toLocaleDateString("fr-FR"))}<br>${esc(d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }))}</div>`;
      row.title = "Cliquer pour réafficher"; row.addEventListener("click", () => showCard(Object.assign({}, normalize(p), { dismiss: true }), true)); list.appendChild(row);
    }
    const foot = document.createElement("div"); foot.className = "nm-journal-foot";
    foot.innerHTML = `<button type="button" data-a="clear">VIDER LE JOURNAL</button>${game.user.isGM ? '<button type="button" data-a="tool">OUTIL DE DIFFUSION</button>' : ""}`;
    foot.querySelector('[data-a="clear"]').addEventListener("click", async () => { await game.settings.set(MID, "journal", []); this.render(); });
    foot.querySelector('[data-a="tool"]')?.addEventListener("click", () => openTool());
    wrap.append(list, foot); return wrap;
  }
  _replaceHTML(result, content) { content.replaceChildren(result); }
  _onClose(o) { super._onClose?.(o); journal = null; }
}
let journal = null;
function openJournal() {
  if (!game.user.isGM && !game.settings.get(MID, "playersJournal")) return ui.notifications.warn("Le journal des notifications est désactivé par le MJ.");
  if (!journal) journal = new NotifJournal(); journal.render({ force: true }); return journal;
}
const THEME_COLORS = { rouge: "#d42020", cramoisi: "#920018", sang: "#480008", "orange-alerte": "#b83c00", orange: "#cc5800", jaune: "#cc9e00", or: "#906800", vert: "#18a030", toxique: "#008800", emeraude: "#005c38", cyan: "#00b8cc", bleu: "#1e7ae8", "bleu-roi": "#141c80", turquoise: "#009278", acier: "#2a3440", violet: "#2a0080", "violet-doux": "#5820b8", plasma: "#440070", nebula: "#241050", rose: "#d820a0", blanc: "#888898", noir: "#181818" };
function themeColor(t) { return THEME_COLORS[t] || "#1e7ae8"; }

/* ───────────────── Contrôles & API ───────────────── */
Hooks.on("getSceneControlButtons", controls => {
  const tools = [];
  if (game.user.isGM) tools.push({ name: "nm-tool", title: "Notifications Manhwa — diffuser", icon: "fa-solid fa-satellite-dish", button: true, order: 90, onChange: () => openTool() });
  if (game.user.isGM || game.settings.get(MID, "playersJournal")) tools.push({ name: "nm-journal", title: "Journal des notifications", icon: "fa-solid fa-book-open", button: true, order: 91, onChange: () => openJournal() });
  if (Array.isArray(controls)) { const c = controls.find(c => c.name === "notes") || controls[0]; for (const t of tools) c.tools.push({ ...t, onClick: t.onChange }); }
  else { const c = controls.notes || controls.tokens; if (c) for (const t of tools) c.tools[t.name] = t; }
});

Hooks.once("ready", () => {
  game.socket.on(SOCK, data => {
    if (data?.type !== "show" || !data.payload) return;
    const p = normalize(data.payload); p.from = data.payload.from; p.ts = data.payload.ts || Date.now();
    const sender = game.users.get(p.from);
    if (!sender?.isGM && !game.settings.get(MID, "allowModuleApi")) return;
    receive(p);
  });
  layer();
  const mod = game.modules.get(MID);
  mod.api = {
    /** Diffuse une notification. opts : {text, theme, colors:{main,glow}, font, duration, dismiss, position, width, zoom, sound, soundPath, volume, chat, targets:'all'|[userIds], gmToo, top, bot, cat:{ic,nom}, image} */
    notify: opts => broadcast(Object.assign({ chat: false }, opts)),
    /** Affiche localement uniquement (aucune diffusion). */
    show: opts => showCard(Object.assign({}, normalize(opts), { dismiss: true }), true),
    open: openTool, openJournal, themes: THEMES, sounds: SOUNDS, fonts: FONTS, customVars: nmCustomVars
  };
  console.log(`${MID} | prêt`);
});
